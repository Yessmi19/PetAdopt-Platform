import { useState, useEffect } from 'react';
import { Pet, AdoptionRequest } from '../types/Pet';

const PETS_STORAGE_KEY = 'pets-data';
const ADOPTIONS_STORAGE_KEY = 'adoption-requests';

export const usePetData = () => {
  const [pets, setPets] = useState<Pet[]>([]);
  const [adoptionRequests, setAdoptionRequests] = useState<AdoptionRequest[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedPets = localStorage.getItem(PETS_STORAGE_KEY);
    const savedAdoptions = localStorage.getItem(ADOPTIONS_STORAGE_KEY);
    
    if (savedPets) {
      setPets(JSON.parse(savedPets));
    }
    
    if (savedAdoptions) {
      setAdoptionRequests(JSON.parse(savedAdoptions));
    }
  }, []);

  // Save pets to localStorage whenever pets change
  useEffect(() => {
    localStorage.setItem(PETS_STORAGE_KEY, JSON.stringify(pets));
  }, [pets]);

  // Save adoption requests to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(ADOPTIONS_STORAGE_KEY, JSON.stringify(adoptionRequests));
  }, [adoptionRequests]);

  const addPet = (pet: Omit<Pet, 'id' | 'dateAdded'>) => {
    const newPet: Pet = {
      ...pet,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString(),
    };
    setPets(prev => [...prev, newPet]);
  };

  const updatePet = (id: string, updates: Partial<Pet>) => {
    setPets(prev => prev.map(pet => 
      pet.id === id ? { ...pet, ...updates } : pet
    ));
  };

  const deletePet = (id: string) => {
    setPets(prev => prev.filter(pet => pet.id !== id));
  };

  const addAdoptionRequest = (request: Omit<AdoptionRequest, 'id' | 'dateSubmitted'>) => {
    const newRequest: AdoptionRequest = {
      ...request,
      id: Date.now().toString(),
      dateSubmitted: new Date().toISOString(),
    };
    setAdoptionRequests(prev => [...prev, newRequest]);
    
    // Update pet status to pending
    updatePet(request.petId, { status: 'pending' });
  };

  const updateAdoptionRequest = (id: string, status: 'approved' | 'rejected') => {
    const request = adoptionRequests.find(req => req.id === id);
    if (!request) return;

    setAdoptionRequests(prev => prev.map(req => 
      req.id === id ? { ...req, status } : req
    ));

    // Update pet status based on adoption decision
    if (status === 'approved') {
      updatePet(request.petId, { 
        status: 'adopted',
        adoptionDate: new Date().toISOString()
      });
    } else {
      updatePet(request.petId, { status: 'available' });
    }
  };

  return {
    pets,
    adoptionRequests,
    addPet,
    updatePet,
    deletePet,
    addAdoptionRequest,
    updateAdoptionRequest,
  };
};