export interface Pet {
  id: string;
  name: string;
  species: 'dog' | 'cat' | 'other';
  breed: string;
  age: number;
  gender: 'male' | 'female';
  size: 'small' | 'medium' | 'large';
  description: string;
  medicalHistory: string;
  vaccinated: boolean;
  sterilized: boolean;
  status: 'available' | 'pending' | 'adopted';
  dateAdded: string;
  adoptionDate?: string;
  photos: string[];
}

export interface AdoptionRequest {
  id: string;
  petId: string;
  petName: string;
  applicantName: string;
  applicantEmail: string;
  applicantPhone: string;
  address: string;
  experience: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  dateSubmitted: string;
}

export interface Report {
  totalPets: number;
  availablePets: number;
  adoptedPets: number;
  pendingAdoptions: number;
  adoptionsBySpecies: Record<string, number>;
  adoptionsByMonth: Record<string, number>;
}