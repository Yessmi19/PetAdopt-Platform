import React, { useMemo } from 'react';
import { Pet, AdoptionRequest } from '../types/Pet';
import { BarChart3, PieChart, TrendingUp, Users, Heart, Clock } from 'lucide-react';

interface ReportsTabProps {
  pets: Pet[];
  adoptionRequests: AdoptionRequest[];
}

export const ReportsTab: React.FC<ReportsTabProps> = ({ pets, adoptionRequests }) => {
  const stats = useMemo(() => {
    const totalPets = pets.length;
    const availablePets = pets.filter(p => p.status === 'available').length;
    const adoptedPets = pets.filter(p => p.status === 'adopted').length;
    const pendingAdoptions = pets.filter(p => p.status === 'pending').length;
    
    const adoptionsBySpecies = pets.reduce((acc, pet) => {
      if (pet.status === 'adopted') {
        acc[pet.species] = (acc[pet.species] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);
    
    const adoptionsByMonth = pets
      .filter(pet => pet.adoptionDate)
      .reduce((acc, pet) => {
        const month = new Date(pet.adoptionDate!).toLocaleDateString('es-ES', { 
          year: 'numeric', 
          month: 'long' 
        });
        acc[month] = (acc[month] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

    return {
      totalPets,
      availablePets,
      adoptedPets,
      pendingAdoptions,
      adoptionsBySpecies,
      adoptionsByMonth,
      adoptionRate: totalPets > 0 ? ((adoptedPets / totalPets) * 100).toFixed(1) : '0',
      pendingRequests: adoptionRequests.filter(req => req.status === 'pending').length,
    };
  }, [pets, adoptionRequests]);

  const StatCard: React.FC<{
    title: string;
    value: string | number;
    icon: React.ReactNode;
    color: string;
    trend?: string;
  }> = ({ title, value, icon, color, trend }) => (
    <div className="bg-white rounded-xl shadow-md p-6 border-l-4" style={{ borderLeftColor: color }}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {trend && <p className="text-xs text-gray-500 mt-1">{trend}</p>}
        </div>
        <div className="text-2xl" style={{ color }}>
          {icon}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Reportes y Estadísticas</h2>
        <p className="text-gray-600">Resumen general de la plataforma de adopción</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total de Mascotas"
          value={stats.totalPets}
          icon={<Users />}
          color="#3B82F6"
          trend="Registradas en el sistema"
        />
        <StatCard
          title="Disponibles"
          value={stats.availablePets}
          icon={<Heart />}
          color="#10B981"
          trend="Listas para adopción"
        />
        <StatCard
          title="Adoptadas"
          value={stats.adoptedPets}
          icon={<TrendingUp />}
          color="#F59E0B"
          trend={`${stats.adoptionRate}% tasa de adopción`}
        />
        <StatCard
          title="En Proceso"
          value={stats.pendingAdoptions}
          icon={<Clock />}
          color="#EF4444"
          trend="Solicitudes pendientes"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Adoptions by Species */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-2 mb-4">
            <PieChart className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Adopciones por Especie</h3>
          </div>
          <div className="space-y-3">
            {Object.entries(stats.adoptionsBySpecies).map(([species, count]) => (
              <div key={species} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="capitalize text-gray-700">
                    {species === 'dog' ? 'Perros' : species === 'cat' ? 'Gatos' : 'Otros'}
                  </span>
                </div>
                <span className="font-semibold text-gray-900">{count}</span>
              </div>
            ))}
            {Object.keys(stats.adoptionsBySpecies).length === 0 && (
              <p className="text-gray-500 text-center py-4">No hay adopciones registradas</p>
            )}
          </div>
        </div>

        {/* Adoptions by Month */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-5 h-5 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">Adopciones por Mes</h3>
          </div>
          <div className="space-y-3">
            {Object.entries(stats.adoptionsByMonth).map(([month, count]) => (
              <div key={month} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="capitalize text-gray-700">{month}</span>
                </div>
                <span className="font-semibold text-gray-900">{count}</span>
              </div>
            ))}
            {Object.keys(stats.adoptionsByMonth).length === 0 && (
              <p className="text-gray-500 text-center py-4">No hay adopciones registradas</p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Adoption Requests */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Solicitudes de Adopción Recientes</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-2">Mascota</th>
                <th className="text-left py-3 px-2">Solicitante</th>
                <th className="text-left py-3 px-2">Email</th>
                <th className="text-left py-3 px-2">Estado</th>
                <th className="text-left py-3 px-2">Fecha</th>
              </tr>
            </thead>
            <tbody>
              {adoptionRequests.slice(0, 5).map((request) => (
                <tr key={request.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-2 font-medium">{request.petName}</td>
                  <td className="py-3 px-2">{request.applicantName}</td>
                  <td className="py-3 px-2">{request.applicantEmail}</td>
                  <td className="py-3 px-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      request.status === 'approved' ? 'bg-green-100 text-green-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {request.status === 'pending' ? 'Pendiente' :
                       request.status === 'approved' ? 'Aprobada' : 'Rechazada'}
                    </span>
                  </td>
                  <td className="py-3 px-2">
                    {new Date(request.dateSubmitted).toLocaleDateString('es-ES')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {adoptionRequests.length === 0 && (
            <p className="text-gray-500 text-center py-8">No hay solicitudes de adopción</p>
          )}
        </div>
      </div>
    </div>
  );
};